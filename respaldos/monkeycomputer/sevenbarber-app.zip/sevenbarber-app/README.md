Stack utilizado para el desarrollo:

Python → Lenguaje de programación principal

Streamlit → Desarrollo web

Google Console → Agendamiento mediante Google Calendar

Gimp → Edición de imágenes

Finalidad:

La aplicación web tiene como objetivo automatizar el proceso de agendamiento de citas en la barbería Seven Barber Club | Riobamba | Ecuador.

Desarrollada por: Monkey Computer .