document.addEventListener("DOMContentLoaded", () => {
  if (typeof gsap === "undefined") return;

  if (typeof ScrollTrigger !== "undefined") {
    gsap.registerPlugin(ScrollTrigger);
  }

  // Hero principal
  const hero = document.querySelector("[data-anim='hero']");
  if (hero) {
    gsap.from(hero, {
      opacity: 0,
      y: 40,
      duration: 1.1,
      ease: "power3.out",
    });
  }

  const heroCard = document.querySelector("[data-anim='hero-card']");
  if (heroCard) {
    gsap.from(heroCard, {
      opacity: 0,
      x: 40,
      duration: 1.1,
      ease: "power3.out",
      delay: 0.2,
    });
  }

  // Secciones con stagger
  if (typeof ScrollTrigger !== "undefined") {
    const staggerSections = document.querySelectorAll("[data-anim='stagger-section']");
    staggerSections.forEach((section) => {
      const items = section.querySelectorAll("[data-anim='item']");
      if (!items.length) return;

      gsap.from(items, {
        opacity: 0,
        y: 30,
        duration: 0.8,
        ease: "power3.out",
        stagger: 0.15,
        scrollTrigger: {
          trigger: section,
          start: "top 80%",
        },
      });
    });
  }
});
